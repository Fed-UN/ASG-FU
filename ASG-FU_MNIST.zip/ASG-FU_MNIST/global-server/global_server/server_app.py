"""Global-Server: A Flower / PyTorch app."""
from flwr.common import Context, ndarrays_to_parameters
from flwr.server import ServerApp, ServerAppComponents, ServerConfig
from flwr.server.strategy import FedAvg
from global_server.task import Net, get_weights, test
import logging
import datetime
import os
from collections import OrderedDict
import torch
# from setuptools.command.build_ext import if_dl
from torchvision.datasets import FashionMNIST
from torchvision.transforms import Compose, ToTensor, Normalize
from torch.utils.data import DataLoader

flwr_logger = logging.getLogger("flwr")
flwr_logger.setLevel(logging.ERROR)

def load_global_testset():
    transform = Compose([
        ToTensor(),
        Normalize((0.1307,), (0.3081,))
    ])
    testset = FashionMNIST(root="../data", train=False, download = True, transform=transform)
    return DataLoader(testset, batch_size=32, shuffle=False)

def get_evaluate_fn():
    testloader = load_global_testset()
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    def evaluate_fn(server_round: int, parameters, config):
        net = Net()
        params_dict = zip(net.state_dict().keys(), parameters)
        state_dict = OrderedDict({k: torch.tensor(v) for k, v in params_dict})
        net.load_state_dict(state_dict)

        loss, accuracy = test(net, testloader, device)

        log_dir = os.path.abspath(os.path.join(os.getcwd(), "../training_logs"))
        os.makedirs(log_dir, exist_ok=True)
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

        log_file = os.path.join(log_dir, "global_training_log.csv")
        if server_round == 0:
            with open(log_file, "a") as f:
                if os.path.getsize(log_file) == 0:  # 添加表头
                    f.write("round,accuracy,time\n")
                f.write(f"{server_round},{accuracy:.4f},{current_time}\n")
        return loss, {"accuracy": accuracy}
    return evaluate_fn

def server_fn(context: Context):
    num_rounds = context.run_config["num-server-rounds"]
    fraction_fit = context.run_config["fraction-fit"]

    ndarrays = get_weights(Net())
    parameters = ndarrays_to_parameters(ndarrays)

    strategy = FedAvg(
        fraction_fit=fraction_fit,
        fraction_evaluate=1.0,
        min_available_clients=2,
        initial_parameters=parameters,
        on_fit_config_fn=lambda server_round: {"server_round": server_round},
        evaluate_fn=get_evaluate_fn()
    )

    config = ServerConfig(num_rounds=num_rounds)
    return ServerAppComponents(strategy=strategy, config=config)

app = ServerApp(server_fn=server_fn)